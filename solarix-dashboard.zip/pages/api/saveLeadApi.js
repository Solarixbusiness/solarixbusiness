import fs from 'fs';
import path from 'path';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  const lead = req.body;
  const filePath = path.join(process.cwd(), 'public', 'leads.json');

  try {
    let existing = [];
    if (fs.existsSync(filePath)) {
      const fileData = fs.readFileSync(filePath);
      existing = JSON.parse(fileData);
    }

    lead.data = new Date().toISOString();
    existing.unshift(lead);

    fs.writeFileSync(filePath, JSON.stringify(existing, null, 2));
    res.status(200).json({ success: true });
  } catch (error) {
    console.error('Errore salvataggio lead:', error);
    res.status(500).json({ error: 'Errore interno del server' });
  }
}
